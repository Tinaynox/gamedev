#pragma once


enum UnitOrder
{
	UnitOrder_Forward		= 1,
	UnitOrder_None			= 0,
	UnitOrder_Backward		= -1
};