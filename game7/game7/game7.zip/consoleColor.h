#pragma once


/////////////////////////////////////
// Enum
enum ConsoleColor
{
	ConsoleColor_Black			= 0,
	ConsoleColor_DarkBlue		= 1,
	ConsoleColor_DarkGreen		= 2,
	ConsoleColor_DarkCyan		= 3,
	ConsoleColor_DarkRed		= 4,
	ConsoleColor_DarkMagenta	= 5,
	ConsoleColor_DarkYellow		= 6,
	ConsoleColor_Gray			= 7,
	ConsoleColor_DarkGray		= 8,
	ConsoleColor_Blue			= 9,
	ConsoleColor_Green			= 10,
	ConsoleColor_Cyan			= 11,
	ConsoleColor_Red			= 12,
	ConsoleColor_Magenta		= 13,
	ConsoleColor_Yellow			= 14,
	ConsoleColor_White			= 15
};